from .mmnist import *
from .mcifar10 import *
from .mtinyimagenet import *